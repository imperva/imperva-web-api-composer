#!/bin/sh
 
# set some globals
USER="admin"
PASS="webco123"
MX="192.168.12.70"

# login and retrieve auth token
AUTH=`echo -n "$USER:$PASS" | base64`
JSESSIONID=`curl -sik -X POST https://$MX:8083/SecureSphere/api/v1/auth/session -H "Authorization: Basic $AUTH" | grep "session-id" | sed 's/^.*=//' | sed 's/\".*$//'`
 
# Create server group
sites=`curl -sik -X GET -H "Cookie: JSESSIONID=$JSESSIONID" https://$MX:8083/SecureSphere/api/v1/conf/sites`
echo $sites

