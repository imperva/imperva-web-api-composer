var siteTree = {};
var responseObj = {};
var actions = {};
var getActions = {};
var xsd = {"complexTypes":{},"elements":{}};
var curUrlParamsAry = [];
var curUrlParamsIndex = 0;

$().ready(function() {
	$("#mainNav").tabs();
	$('#actions').change(function(){ changeAction(); curUrlParamsIndex=0; getURLParams(); });
	$('#method').change(function(){
		//$('#JSONparams .fieldwrapper').hide();
		/*$.each(actions[$("#actions").val()].methods[$('#method').val()].jsonParams, function(i,param) { 
			$('#'+param.name+'tr').show();
		});*/
		renderJSONParamsHTML();
	});
	$('#siteName').change(function(){
		renderJSONParamsHTML();
	});

	$('#db-service-type').change(function(){ 
		$('#ports').val(dbPortMapping[$(this).val()]);
		updateJSON(); 
	});
	$('#JSONparams input, #JSONparams textarea').blur(function(){ updateJSON(); });
	$('#JSONparams select').change(function(){ updateJSON(); });
	$('#requestUrl').keyup(function(){ checkForm(); updateCURL(); });
	$('#server').blur(function(){ updateReqURL(); });
	$.each(listOfMXs.MXServers, function(i,MX) { 
		var isDefault = ''; 
		if (MX.default) { sDefault=' selected '; $('#server').parent().parent().hide(); }
		$('#MXServers').append('<option value="'+MX.ip+'">'+MX.displayName+' ('+MX.ip+')</option>'); 
	});
	$('#MXServers').attr("disabled", false).append('<option value="entermypwn">Enter My Own</option>'); 
	$('#MXServers').change(function(){
		if ($('#MXServers').val()=='entermypwn') {
			$('#server').parent().parent().show();
		} else {
			$('#server').val($('#MXServers').val());
			$('#server').parent().parent().hide();
		}
		updateReqURL();
	 });
	$('#server').val($('#MXServers').val());
	loadAll();
	updateJSON();
});

function initCopyButtons(){
	$('.ui-icon-copy').unbind("click").click(function(){ 
		var id = this.id.substring(0,this.id.length-4);
		if ($("#"+id).val()!='') {
			if ($("#"+id).hasClass("query")) {
				$("#requestUrl").val($("#requestUrl").val().replace(id+"={string}",id+"="+$('#'+id).val()+"").replace(id+"={list}",id+"="+$('#'+id).val()+"").replace(id+"={boolean}",id+"="+$('#'+id).val()+""));
			} else {
				$("#requestUrl").val($("#requestUrl").val().replace("{"+id+"}",$('#'+id).val()));
			}
		}
		checkForm();
	});
}

function checkForm() {
	var isok = true;
	if (!($('#requestUrl').val().indexOf('{') == -1)) {
		$('#requestUrl').addClass('errors');
		isok=false;
	} else {
		$('#requestUrl').removeClass('errors');
	}
	updateCURL();
	return isok;
}

// Main AJAX function to proxy API calls
function makeCall(action,method,callback,postDataObj) {
	if (action!=undefined || checkForm()) {	
		var postData = $('#data').val();
		if (postDataObj!=undefined) postData = JSON.stringify(postDataObj);
		$('#result').val('processing...');
		var requestUrl = $('#server').val()+$('#actions').val();
		if (action!=undefined) {
			requestUrl = defConfig.proto+'://'+$('#server').val()+':'+defConfig.port+defConfig.actionPrefix+action;
		} else if ($('#requestUrl').val() != ($('#server').val()+$('#actions').val())) {
			requestUrl = $('#requestUrl').val();
		}
		if (method==undefined) method = $('#method').val();
		var postParams = JSON.parse($('#data').val());
		//var defReqUrl = "api_post.php?server="+requestUrl;
		//if (reqUrl==undefined) reqUrl = defReqUrl;
		var reqUrl = "api_post.php?server="+requestUrl;
		reqUrl += "&session="+$('#jsessionid').val();
		reqUrl += "&contentType="+$('#contentType').val();
		reqUrl += "&method="+method;
	
		jQuery.ajax ({
			url: encodeURI(reqUrl),
			type: "POST",
			data: postData,
			dataType: "json",
			contentType: "application/json; charset=utf-8",
			success: function(data){
				responseObj = data;
				$('#result').val(JSON.stringify(data));
				if (callback!=undefined) { 
					return callback(data); 
				}
			}
		});	
	/*	$.post(encodeURI(reqUrl), postParams, function(data) {
			responseObj = data;
			$('#result').val(JSON.stringify(data));
			if (callback!=undefined) { 
				return callback(data); 
			}
		});*/
	}
}

// Update UI display/fields based on selected action
function changeAction() {
	var reqObj = {};
	updateReqURL();
	$('.fieldwrapper').hide();
	$('#method option').attr('disabled','disabled');
	if (actions[$("#actions").val()] != undefined) {
		curUrlParamsAry = [];
		$("#URLparams table").html('');
		$.each(actions[$("#actions").val()].methods, function(method,obj) { 
			$('#method option[value="'+method+'"]').removeAttr('disabled');
		});
		$("#method option:not([disabled]):first").attr('selected', 'selected');
		if (actions[$("#actions").val()].methods[$('#method').val()].urlParams.length!=0) $('#requestUrl').val($('#requestUrl').val()+"?"); 
		$.each(actions[$("#actions").val()].methods[$('#method').val()].urlParams, function(i,param) { 
			var str = param.name+'={'+param.type+'}';
			if (actions[$("#actions").val()].methods[$('#method').val()].urlParams.length<(i-1)) str += '&';
			$('#requestUrl').val($('#requestUrl').val()+str);
		});
		$.each($("#actions").val().split('/'), function(i,param) {
			if (param.substr(0,1)=="{" && param.substr(param.length-1)=="}") {
				param = param.substr(1,param.length-2);
				var displayName = param.replace(/([A-Z])/g, ' $1').replace('I P','IP').replace('I D','ID').replace('Db ','DB ');
				displayName = displayName.substr(0,1).toUpperCase()+displayName.substr(1);
				$("#URLparams table").append('<tr id="'+param+'tr" class="fieldwrapper"><td align="right" width="140"><label for="'+param+'">'+displayName+': </label></td>'+
					'<td><a href="javascript:void(0)" class="ui-icon ui-icon-copy" id="'+param+'_btn" title="Copy to Request URL">copy</a>'+
					'<select name="'+param+'" id="'+param+'" class="min"><option value=""></option></select></td></tr>');
				curUrlParamsAry.push({"name":param,"desc":displayName});
			}
		});
		$.each(actions[$("#actions").val()].methods[$("#method").val()].urlParams, function(i,param) {
			$("#URLparams table").append('<tr id="'+param.name+'tr" class="fieldwrapper"><td align="right" width="140"><label for="'+param.name+'">'+param.name+': </label></td>'+
				'<td><a href="javascript:void(0)" class="ui-icon ui-icon-copy" id="'+param.name+'_btn" title="Copy to Request URL">copy</a>'+
				'<select name="'+param.name+'" id="'+param.name+'" class="min query"><option value=""></option></select></td></tr>');
			curUrlParamsAry.push({"name":param.name,"desc":param.name});
		});
		initCopyButtons();
		// show the params for the selected action, might remove this later as it is not necessary
		//$.each(actions[$("#actions").val()].methods[$('#method').val()].jsonParams, function(i,param) { $('#'+param.name+'tr').show(); });
	}
	if ($('#jsessionid').val()=="") {
		$("#usernametr").show();
		$("#passwordtr").show();
		$("#method option").attr('disabled','disabled');
		$("#method").val('POST');
		reqObj = {"username":$('#username').val(),"password":$('#password').val()}
		$('#data').val(JSON.stringify(reqObj));
	} else {
		renderJSONParamsHTML();
		updateJSON();
	}
}
function updateJSON(){
	var reqObj = {};
	if (actions[$("#actions").val()] != undefined) {
		$.each(actions[$("#actions").val()].methods[$('#method').val()].jsonParams, function(i,param) { 
			if (param.type=='array') {
				reqObj[param.name] = JSON.parse($('#'+param.name).val());
				//reqObj[param.name] = param.values.substr(1,(param.values.length-2)).split(',');
			} else if (param.type=='obj') {
				reqObj[param.name] = JSON.parse($('#'+param.name).val());
			} else if (param.type=='int') {
				reqObj[param.name] = parseInt($('#'+param.name).val(),10);
			} else if (param.type=='boolean') {
				var boolVal = false; if ($('#'+param.name).val()=='true') boolVal = true;
				reqObj[param.name] = boolVal;
			} else {
				reqObj[param.name] = $('#'+param.name).val();
			}
			/*if (param.name=='ports') {
				var strAry = $('#'+param.name).val().split(',');
				for(var i = 0; i < strAry.length; i++)
					strAry[i] = parseInt(strAry[i], 10);
				reqObj[param.name] = strAry;
			} else if (param.name=='db-mappings') {
				reqObj[param.name] = JSON.parse($('#'+param.name).val().replace('\r','').replace('\n','').trim());
			} else {
				reqObj[param.name] = $('#'+param.name).val();
			}*/
		});
	}
	//if ($('#jsessionid').val()=="") reqObj = {"username":$('#username').val(),"password":$('#password').val()};	
	if ($('#jsessionid').val()=="") reqObj['Authorization Header'] = "Authorization: Basic "+btoa($('#username').val()+':'+$('#password').val()); 
	//console.log(reqObj);
	$('#data').val(JSON.stringify(reqObj));
	$('#JSONparams input').blur(function(){ updateJSON(); });
	$('#JSONparams textarea').blur(function(){ updateJSON(); });
	$('#JSONparams select').change(function(){ updateJSON(); });
	updateCURL();
}
function updateCURL(){
	if (!$('#requestUrl').hasClass('errors')) {
		var str = 'curl -ik -X '+$('#method').val()+' ';
		if ($('#jsessionid').val()=="") {
			str += '-H "Authorization: Basic '+btoa($('#username').val()+':'+$('#password').val())+'"'; 
		} else {
			str += '-H "Cookie: '+$('#jsessionid').val()+'" -H "Content-Type: application/json" -H "Accept: application/json" ';
			if ($('#data').val()!='{}') str += " -d '"+$('#data').val()+"' ";
		}
		//str += ' '+$('#server').val()+encodeURI($('#actions').val());
		str += ' '+encodeURI($('#requestUrl').val());
		$('#curlUrl').val(str);
	} else {
		$('#curlUrl').val('');
	}
}
function updateReqURL() {
	$('#requestUrl').val(defConfig.proto+'://'+$('#server').val()+':'+defConfig.port+defConfig.actionPrefix+$('#actions').val());
	checkForm();
}

function login() {
	var postParams = {
		"username":$("#username").val(),
		"password":$("#password").val()
	};
	$('#result').val('processing...');
	var reqUrl = "api_login.php?server="+$('#requestUrl').val();
	reqUrl += "&contentType="+$('#contentType').val();
	reqUrl += "&method="+$('#method').val();
	$.post(encodeURI(reqUrl), postParams, function(data) {
		responseObj = data;
		$('#result').val(JSON.stringify(data));
		if (data.errors==undefined) {
			$.gritter.add({ title: 'Successful Login', text: "Loading XSD File..."});
			$('#jsessionid').val(data['session-id']);
			$("#usernametr").hide();
			$("#passwordtr").hide();
			$("#login").hide();
			$("#logoutDiv").show();
			$("#curUser").html("Logged is as user: <b>"+$("#username").val()+"</b>");
			$("#execute").show();
			$("#loadSiteTreeData").show();
			$("#actions option").removeAttr('disabled');
			//loadWadl();
			loadXsd();
			$('#MXServers').attr("disabled", true); 
			$('#server').attr('readonly', true);
			//changeAction();
		} else {
			$.gritter.add({ title: '<span>Error: </span>'+data.errors[0]['error-code'], text: data.errors[0]['description'], time: 20000 });
		}
	});
}

function loadAll() {
	$.each(defConfig, function(key,val) { $("#"+key).val(val); });
	
	$("#login").show();
	$("#logoutDiv").hide();
	$("#curUser").html(' ');
	$("#execute").hide();
	$("#loadSiteTreeData").hide();
	$("#actions option").attr('disabled','disabled');
	$("#actions option:eq(0)").removeAttr('disabled').attr('selected', 'selected');
	clearAllFields();
	changeAction();
}

function loadXsd() {
	var requestUrl = defConfig.proto+'://'+$('#server').val()+':'+defConfig.port+defConfig.actionPrefix+"/application.wadl/xsd0.xsd";
	//var postParams = JSON.parse($('#data').val());
	var reqUrl = "api_wadl.php?server="+requestUrl;
	reqUrl += "&session="+$('#jsessionid').val();
	reqUrl += "&contentType="+$('#contentType').val();
	reqUrl += "&method="+"GET";
	
	jQuery.ajax ({
		url: encodeURI(reqUrl),
		type: "POST",
		contentType: "application/json; charset=utf-8",
		success: function(data){
			$.gritter.add({ title: 'Processing...', text: "Parsing XSD, loading WADL"});
			var xsdXML = $.parseXML(data);
			$xsdObj = $(xsdXML);
			responseObj = $xsdObj;
			//console.log($xsdObj.children().first().children());
			$xsdObj.children().first().children().each(function(i) {
				if ((this).nodeName=="xs:element") xsd.elements[$(this).attr("name")] = $(this).attr("type");
			});
			$xsdObj.find("xs\\:complexType").each(function(i) {
				var complexType = $(this).attr("name");
				xsd.complexTypes[complexType] = [];
				$(this).find('xs\\:element').each(function(j) {
	    			var type = 'n/a'; if ($(this).attr('type')!=undefined) type = $(this).attr('type').substr(3); 
	    			xsd.complexTypes[complexType].push({"name":$(this).attr('name'),"type":type});
	    		});
    		});
    		loadWadl();
		}
	});	
}

function loadWadl() {
	var requestUrl = defConfig.proto+'://'+$('#server').val()+':'+defConfig.port+defConfig.actionPrefix+"/application.wadl";
	var reqUrl = "api_wadl.php?server="+requestUrl;
	reqUrl += "&session="+$('#jsessionid').val();
	reqUrl += "&contentType="+$('#contentType').val();
	reqUrl += "&method="+"GET";

	jQuery.ajax ({
		url: encodeURI(reqUrl),
		type: "POST",
		contentType: "application/json; charset=utf-8",
		success: function(data){
			var wadlXML = $.parseXML(data);
			$wadlObj = $(wadlXML);
			responseObj = $wadlObj;
			var resources = $wadlObj.find("resources").eq(0).children().eq(0).children();
			var basePath = $wadlObj.find("resources").eq(0).attr("base");
			var defActionObjStr = '{"methods":{}}';
			var defMethodObjStr = '{"urlParams":[],"jsonParams":[]}';
			$.each(resources, function(i_0,res) {
				var resPath = $(res).attr('path');
				$.each(resources.eq(i_0).children(), function(i_1,subRes1) {
					var resSubPath1 = String(resPath+"/"+$(subRes1).attr('path')).replace("//","/");
					$.each($(subRes1).children(), function(i_2,subRes2) {
						if ((subRes2).nodeName=="resource") {
							var resSubPath2 = String(resSubPath1+"/"+$(subRes2).attr('path')).replace("//","/");
							if ($(subRes2).find("method").children().length>0) actions[resSubPath2] = JSON.parse(defActionObjStr);
							$.each($(subRes2).children(), function(i_3,subRes3) {
								if ((subRes3).nodeName=="resource") {
									var resSubPath3 = String(resSubPath2+"/"+$(subRes3).attr('path')).replace("//","/");
									if ($(subRes3).find("method").children().length>0) actions[resSubPath3] = JSON.parse(defActionObjStr);
									$.each($(subRes3).children(), function(i_4,subRes4) {
										if ((subRes4).nodeName=="resource") {
											var resSubPath4 = String("/"+$(subRes4).attr('path')).replace("//","/");
											if ($(subRes4).find("method").children().length>0) actions[resSubPath4] = JSON.parse(defActionObjStr);
										} else if ((subRes4).nodeName=="method") {
											if (actions[resSubPath3]==undefined) actions[resSubPath3] = JSON.parse(defActionObjStr);
											if ($(subRes4).attr('id').search(/getall/i)==0) getActions[$(subRes4).attr('id').toLowerCase()] = resSubPath3;
											actions[resSubPath3].methods[$(subRes4).attr("name")] = JSON.parse(defMethodObjStr);
											$.each($(subRes4).find("request").first().children(), function(c_i,param) {
												if ((param).nodeName=="param") {
													if ($(param).attr("style")=='query') {
														if ($(param).attr("type").substr(0,3)=="xs:") $(param).attr("type",$(param).attr("type").substr(3));
														if (jsonParamMapping[$(param).attr("name")]!=undefined) { param=jsonParamMapping[$(param).attr("name")]; } else { $(param).attr("values",$(param).attr("type")); }
														actions[resSubPath3].methods[$(subRes4).attr("name")].urlParams.push({"name":$(param).attr("name"),"type":$(param).attr("type"),"values":$(param).attr("values")});
													}
												} else if ((param).nodeName=="ns2:representation") {
													if (xsd.complexTypes[xsd.elements[$(param).attr("element")]]!=undefined) {
														$.each(xsd.complexTypes[xsd.elements[$(param).attr("element")]], function(p_i,param) {
															if (formatJSONParamObj(param)!=null) actions[resSubPath3].methods[$(subRes4).attr("name")].jsonParams.push(formatJSONParamObj(param));
														});
													}
												}
											});
										}
									});
								} else if ((subRes3).nodeName=="method") {
									if (actions[resSubPath2]==undefined) actions[resSubPath2] = JSON.parse(defActionObjStr);
									if ($(subRes3).attr('id').search(/getall/i)==0) getActions[$(subRes3).attr('id').toLowerCase()] = resSubPath2;
									actions[resSubPath2].methods[$(subRes3).attr("name")] = JSON.parse(defMethodObjStr);
									$.each($(subRes3).find("request").first().children(), function(b_i,param) {
										if ((param).nodeName=="param") {
											if ($(param).attr("style")=='query') {
												if ($(param).attr("type").substr(0,3)=="xs:") $(param).attr("type",$(param).attr("type").substr(3));
												if (jsonParamMapping[$(param).attr("name")]!=undefined) { param=jsonParamMapping[$(param).attr("name")]; } else { $(param).attr("values",$(param).attr("type")); }
												actions[resSubPath2].methods[$(subRes3).attr("name")].urlParams.push({"name":$(param).attr("name"),"type":$(param).attr("type"),"values":$(param).attr("values")});
											}
										} else if ((param).nodeName=="ns2:representation") {
											if (xsd.complexTypes[xsd.elements[$(param).attr("element")]]!=undefined) {
												$.each(xsd.complexTypes[xsd.elements[$(param).attr("element")]], function(p_i,param) {	
													if (formatJSONParamObj(param)!=null) actions[resSubPath2].methods[$(subRes3).attr("name")].jsonParams.push(formatJSONParamObj(param));
												});
											}
										}
									});
								}
							});
						} else if ((subRes2).nodeName=="method") {
							if (actions[resSubPath1]==undefined) actions[resSubPath1] = JSON.parse(defActionObjStr);
							if ($(subRes2).attr('id').search(/getall/i)==0) getActions[$(subRes2).attr('id').toLowerCase()] = resSubPath1;
							actions[resSubPath1].methods[$(subRes2).attr("name")] = JSON.parse(defMethodObjStr);
							$.each($(subRes2).find("request").first().children(), function(a_i,param) {
								if ((param).nodeName=="param") {
									if ($(param).attr("style")=='query') {
										if ($(param).attr("type").substr(0,3)=="xs:") $(param).attr("type",$(param).attr("type").substr(3));
										if (jsonParamMapping[$(param).attr("name")]!=undefined) { param=jsonParamMapping[$(param).attr("name")]; } else { $(param).attr("values",$(param).attr("type")); }
										actions[resSubPath1].methods[$(subRes2).attr("name")].urlParams.push({"name":$(param).attr("name"),"type":$(param).attr("type"),"values":$(param).attr("values")});
									}
								} else if ((param).nodeName=="ns2:representation") {
									if (xsd.complexTypes[xsd.elements[$(param).attr("element")]]!=undefined) {
										$.each(xsd.complexTypes[xsd.elements[$(param).attr("element")]], function(p_i,param) {
											if (formatJSONParamObj(param)!=null) actions[resSubPath1].methods[$(subRes2).attr("name")].jsonParams.push(formatJSONParamObj(param));
										});
									}
								}
							});
						}
					});
				});
			});
			// Override Methods 
			$.each(actions, function(action,actionObj) {
				if (jsonParamMapping[action]!=null) {
					$.each(actionsParamMapping[action].methods, function(mappedMethod,methodObj) {
						if (action=='/v1/conf/dbServices/{siteName}/{serverGroupName}/{dbServiceName}' && mappedMethod=='PUT'){
							console.log(methodObj);
						} 
						actions[action].methods[mappedMethod] = methodObj;
					});
				}
			});
			$('#actions').html("");
			var actionkeys = Object.keys(actions);
			actionkeys.sort();
			//actions.sort(function(a,b) { return a - b; });
			//$.each(actions, function(action,obj) {
			for (var i=0; i<actionkeys.length; i++) { 
				$('#actions').append('<option value="'+actionkeys[i]+'">'+actionkeys[i]+'</option>');
			}
			//});
			$.gritter.add({ title: 'Success', text: "Loaded WADL and populated actions"});
			changeAction();
		}
	});	
	//https://10.100.53.10:8083/SecureSphere/api/application.wadl
	/*xmlDoc = $.parseXML( xml ),
	$xml = $( xmlDoc ),
	$title = $xml.find( "title" );*/
}

function formatJSONParamObj(param){
	if ($(param).attr("type").substr(0,3)=="xs:") $(param).attr("type",$(param).attr("type").substr(3));
	if (jsonParamMapping[$(param).attr("name")]!=undefined) { param=jsonParamMapping[$(param).attr("name")]; } else { $(param).attr("values",$(param).attr("type")); }
	return param;
}


function clearAllFields() {
	$('#result').val('');
	//$("#siteName").html('');
	//$("#serverGroupName").html('');
	//$("#serviceName").html('');
	//$("#applicationName").html('');
	$("#jsessionid").val('');
}

function resolveActionPlaceHolders(str){
	$.each(str.split('/'), function(i,param) {
		if (param.substr(0,1)=="{" && param.substr(param.length-1)=="}") {
			param = param.substr(1,param.length-2);
			str = str.replace("{"+param+"}",$("#"+param).val());
		}
	});	
	return str;
}

function getURLParams(curObj) {
	if (curObj!=undefined) setCurrentParamIndex(curObj);
	if (curUrlParamsAry.length>(curUrlParamsIndex)) {
		$('#'+curUrlParamsAry[curUrlParamsIndex].name).html('<option value="">loading...</option>');
		for (var i=(curUrlParamsIndex+1); i<curUrlParamsAry.length; i++) {
			$('#'+curUrlParamsAry[i].name).html('');
		}
		var curParam = curUrlParamsAry[curUrlParamsIndex].name;
		if (curParam=="priority"){
			if ($("#actions").val()=="/v1/conf/webServices/{siteName}/{serverGroupName}/{webServiceName}/hostToAppMappings/{webApplicationName}/{priority}") {
				curParam="priority_hostToAppMappings";
			} else if ($("#actions").val()=="/v1/conf/webServices/{siteName}/{serverGroupName}/{webServiceName}/krpInboundRules/{gatewayGroupName}/{aliasName}/{gatewayPort}/krpOutboundRules/{priority}") {
				curParam="priority_krpOutboundRules";
			}
		}
		if (getObjectActionMapping[curParam]!=undefined) {
			var curAction = resolveActionPlaceHolders(getObjectActionMapping[curParam].default);
			console.log("curParam="+curParam+" | $('#actions').val()="+$('#actions').val()+" | getObjectActionMapping[curParam][$('#actions').val()]="+getObjectActionMapping[curParam][$('#actions').val()]);
			if (getObjectActionMapping[curParam][$('#actions').val()]!=undefined) curAction = resolveActionPlaceHolders(getObjectActionMapping[curParam][$('#actions').val()]);
			console.log(curAction);
			if (curAction!=undefined) makeCall(curAction,'GET',renderURLParams,{});
		} else {
			if (jsonParamMapping[curParam]!=undefined) {
				if (jsonParamMapping[curParam].type=="list") {
					$('#'+curUrlParamsAry[curUrlParamsIndex].name).html('');
					$.each(jsonParamMapping[curParam].values, function(i,value) { 
						$('#'+curUrlParamsAry[curUrlParamsIndex].name).append('<option value="'+value+'">'+value+'</option>'); 
					});
				} else if (jsonParamMapping[curParam].type=='boolean') {
					$('#'+curUrlParamsAry[curUrlParamsIndex].name).html('<option value="true">true</option><option value="false">false</option>');
				} else if (jsonParamMapping[curParam].type=='string') {
					$('#'+curUrlParamsAry[curUrlParamsIndex].name).html('<option value="'+jsonParamMapping[curParam].values+'">'+jsonParamMapping[curParam].values+'</option>');
				}
			} else {
				for (var i=(curUrlParamsIndex); i<curUrlParamsAry.length; i++) {
					$('#'+curUrlParamsAry[i].name).html('<option value="">Not Currently Available</option>');
				}
			}
		}
	}
}

function setCurrentParamIndex(obj){
	var curIndex = 0;
	$.each(curUrlParamsAry, function(i,param){ param.isCurObj=false; });
	if (obj!=undefined) {
		$.each(curUrlParamsAry, function(i,param){ if (param.name==obj.id) curUrlParamsIndex=(i+1); });
	}
	return curIndex;
}

function renderURLParams(data){
	var tmpAry = {"list":[]};
	if (curUrlParamsAry[curUrlParamsIndex].name=='IPAddress') {
		$.each(data,function(i, ary){if (ary.length!=0) { $.each(ary,function(i, obj){ tmpAry.list.push(obj.ip); }); } });
		data = tmpAry;
	} else if (curUrlParamsAry[curUrlParamsIndex].name=='priority') {
		$.each(data,function(i, ary){if (ary.length!=0) { $.each(ary,function(i, obj){ tmpAry.list.push(obj.priority); }); } });
		data = tmpAry;
	} else if (curUrlParamsAry[curUrlParamsIndex].name=='applicationGroupName' || curUrlParamsAry[curUrlParamsIndex].name=='agentName') {
		$.each(data,function(i, ary){if (ary.length!=0) { $.each(ary,function(i, obj){ tmpAry.list.push(obj.name); }); } });
		data = tmpAry;
	} else if (curUrlParamsAry[curUrlParamsIndex].name=='dataInterfaceID') {
		$.each(data,function(i, ary){if (ary.length!=0) { $.each(ary,function(i, obj){ tmpAry.list.push(obj.id); }); } });
		data = tmpAry;
	}
	populateSelect(curUrlParamsAry[curUrlParamsIndex].name,data);
	$("#"+curUrlParamsAry[curUrlParamsIndex].name).unbind().change(function(){ 
		getURLParams(this); 
	});
	curUrlParamsIndex++;
	getURLParams();
}

function populateSelect(id,listObj){
	$('#'+id).html('');
	$.each(listObj,function(key, ary){
		if (ary.length!=0 && key!='errors') {
			$.each(ary,function(j, val){
				$('#'+id).append('<option value="'+val+'">'+val+'</option>');
			});
		} else {
			$('#'+id).html('<option>Not Currently Available</option>');
		}
	});
}

function renderJSONParamsHTML(){
	$("#JSONparams table").html('');
	$.each(actions[$("#actions").val()].methods[$('#method').val()].jsonParams, function(i,param) {
		if (param.name!=undefined) {
			var displayName = param.name.replace(/([A-Z])/g, ' $1').replace('I P','IP').replace('I D','ID').replace('Db ','DB ').replace('-',' ').replace('ip','IP');
			displayName = displayName.substr(0,1).toUpperCase()+displayName.substr(1);
			var str = '<tr id="'+param.name+'tr" class="fieldwrapper"><td align="right"><label for="'+param.name+'">'+displayName+': </label></td><td>';
			if (param.type=="list") {
				str += '<select name="'+param.name+'" id="'+param.name+'">';
				$.each(param.values, function(i,value) { str += '<option value="'+value+'">'+value+'</option>'; });
				str += '</select>';
			} else if (param.type=="boolean") {
				str += '<select name="'+param.name+'" id="'+param.name+'">';
				str += '<option value="true">true</option><option value="false">false</option>';
				str += '</select>';
			} else if (param.type=="array" || param.type=="obj") {
				str += '<textarea class="'+param.type+'" name="'+param.name+'" id="'+param.name+'" style="width:200px;">'+JSON.stringify(param.values)+'</textarea>';
				//{"database":"finance","schema":"payroll","application":"financeApp"}, {database":"HR","schema":"","application":"HRApp"}
			} else {
				str += '<input type="text" class="'+param.type+'" name="'+param.name+'" id="'+param.name+'" value="'+param.values+'" />';
			}
			str += '</td></tr>';
			$("#JSONparams table").append(str);
		}
		/*
		if ($(param).attr("name") !=undefined) {
			var displayName = $(param).attr("name").replace(/([A-Z])/g, ' $1').replace('I P','IP').replace('I D','ID').replace('Db ','DB ').replace('-',' ').replace('ip','IP');
			displayName = displayName.substr(0,1).toUpperCase()+displayName.substr(1);
			var str = '<tr id="'+$(param).attr("name")+'tr" class="fieldwrapper"><td align="right"><label for="'+$(param).attr("name")+'">'+displayName+': </label></td><td>';
			if ($(param).attr("type")=="list") {
				str += '<select name="'+$(param).attr("name")+'" id="'+$(param).attr("name")+'">';
				$.each($(param).attr("values"), function(i,value) { str += '<option value="'+value+'">'+value+'</option>'; });
				str += '</select>';
			} else if ($(param).attr("type")=="array" || $(param).attr("type")=="obj") {
				str += '<textarea class="'+$(param).attr("type")+'" name="'+$(param).attr("name")+'" id="'+$(param).attr("name")+'" style="width:200px;">'+JSON.stringify($(param).attr("values"))+'</textarea>';
				//{"database":"finance","schema":"payroll","application":"financeApp"}, {database":"HR","schema":"","application":"HRApp"}
			} else {
				str += '<input type="text" class="'+$(param).attr("type")+'" name="'+$(param).attr("name")+'" id="'+$(param).attr("name")+'" value="'+$(param).attr("values")+'" />';
			}
			str += '</td></tr>';
			$("#JSONparams table").append(str);
		}
		*/
	});
	updateJSON(); 
}

